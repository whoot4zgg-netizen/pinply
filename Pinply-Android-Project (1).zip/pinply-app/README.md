# Pinply Android APK project

A simple Android WebView wrapper for https://pinply.netlify.app/. It keeps the website's existing interface and requires an internet connection.

## Easiest build route (GitHub Actions)
1. Create/sign in to a GitHub account.
2. Create a new repository named `Pinply`.
3. Upload all files in this folder to the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab and select **Build Pinply APK**.
5. Press **Run workflow** (or push files to `main` to trigger it).
6. When the workflow finishes, open its run and download the **Pinply-APK** artifact.
7. Extract the ZIP and open `app-debug.apk` on your Android phone to install. Android may ask you to allow installs from that source.

## Build with Android Studio
Open this folder as a project, allow Gradle sync, then choose Build > Build APK(s). The APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

This is an unsigned debug APK for personal testing, not a Play Store release. The app loads the site over HTTPS and does not redesign the website.
